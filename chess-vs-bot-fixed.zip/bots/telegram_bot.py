# -*- coding: utf-8 -*-
"""
Telegram-бот: команда /start открывает Mini App с шахматами.

Запуск (polling, для локальной разработки):
    python bots/telegram_bot.py

Для продакшена переключите aiogram на webhook-режим (см. README).

Переменные окружения (файл .env):
    BOT_TOKEN   — токен от @BotFather
    WEBAPP_URL  — публичный https-URL Mini App (например, https://myapp.onrender.com)
"""

import asyncio
import os

from aiogram import Bot, Dispatcher, F
from aiogram.filters import Command
from aiogram.types import (InlineKeyboardMarkup, Message,
                           WebAppInfo)
from aiogram.types.inline_keyboard_button import InlineKeyboardButton
from dotenv import load_dotenv

load_dotenv()
BOT_TOKEN = os.getenv("BOT_TOKEN")
WEBAPP_URL = os.getenv("WEBAPP_URL")

if not BOT_TOKEN:
    raise SystemExit("Задайте BOT_TOKEN в файле .env")
if not WEBAPP_URL:
    raise SystemExit("Задайте WEBAPP_URL в файле .env")
if not WEBAPP_URL.startswith("https://"):
    raise SystemExit("WEBAPP_URL должен начинаться с https:// (требование Telegram Mini Apps)")

bot = Bot(token=BOT_TOKEN)
dp = Dispatcher()


@dp.message(Command("start"))
async def cmd_start(message: Message):
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(
            text="♞ Играть в шахматы",
            web_app=WebAppInfo(url=WEBAPP_URL),
        )]
    ])
    await message.answer(
        "Привет! Сыграйте со мной в шахматы — три уровня сложности.\n"
        "Нажмите кнопку ниже 👇",
        reply_markup=keyboard,
    )


@dp.message(F.text)
async def fallback(message: Message):
    await message.answer("Нажмите /start, чтобы открыть шахматы.")


async def main():
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
