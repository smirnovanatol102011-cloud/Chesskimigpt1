# -*- coding: utf-8 -*-
"""Консольный интерфейс: python console.py"""

import random
import sys
import time

import chess

from chessbot import ChessGame, Difficulty, bot_move, hint, render_board


def choose_color() -> int:
    print("За кого играете?")
    print("  w — белые (ходите первым)")
    print("  b — чёрные (бот начинает)")
    print("  r — случайно")
    while True:
        a = input("> ").strip().lower()
        if a in ("w", "white", "б", "белые"):
            return chess.WHITE
        if a in ("b", "black", "ч", "чёрные", "черные"):
            return chess.BLACK
        if a in ("r", "rand", "random", "с", "случайно"):
            return random.choice([chess.WHITE, chess.BLACK])


def choose_difficulty() -> Difficulty:
    print("\nУровень сложности:")
    print("  1 — лёгкий")
    print("  2 — средний")
    print("  3 — тяжёлый")
    while True:
        a = input("> ").strip()
        if a in ("1", "2", "3"):
            return Difficulty(int(a))


def play_game():
    color = choose_color()
    diff = choose_difficulty()
    game = ChessGame(human_color=color, difficulty=diff)

    print("\nФормат хода: e4 или e2e4, превращение: e7e8q")
    print("Команды: 'moves', 'board', 'hint', 'takeback', 'new', 'quit'\n")

    while not game.is_over:
        print("\n" + game.render())

        if game.is_human_turn:
            raw = input("Ваш ход: ").strip().lower()
            if raw == "quit":
                sys.exit(0)
            if raw == "moves":
                print(game.history_san())
                continue
            if raw == "board":
                continue
            if raw == "hint":
                print(f"Подсказка: {hint(game.board)}")
                continue
            if raw == "takeback":
                print("Ход отменён." if game.takeback() else "Отменять нечего.")
                continue
            if raw == "new":
                play_game()
                return
            move = game.parse_human_move(raw)
            if move is None:
                print("Некорректный или невозможный ход (возможно, вас держат под шахом).")
                continue
            game.push(move)
        else:
            start = time.time()
            move = bot_move(game.board, game.difficulty)
            print(f"Бот: {game.board.san(move)}   (думал {time.time() - start:.1f} c)")
            game.push(move)

    print("\n" + game.render())
    if game.result.value == "checkmate":
        winner = "Чёрные" if game.winner_color == chess.BLACK else "Белые"
        print(f"Мат! Победили {winner}.")
    elif game.result.value == "stalemate":
        print("Пат — ничья.")
    else:
        print("Ничья.")

    if input("\nЕщё партию? (y/n): ").strip().lower() in ("y", "yes", "д", "да"):
        play_game()


if __name__ == "__main__":
    try:
        play_game()
    except (KeyboardInterrupt, EOFError):
        print("\nДо встречи!")
