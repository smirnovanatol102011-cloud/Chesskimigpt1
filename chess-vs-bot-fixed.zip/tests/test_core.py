# -*- coding: utf-8 -*-
"""Тесты движка, ИИ и API сервера."""

import chess

from chessbot import ChessGame, Difficulty, bot_move, hint, parse_move
from chessbot.engine import GameResult


def test_parse_move_san_and_uci():
    board = chess.Board()
    assert parse_move(board, "e4").uci() == "e2e4"
    assert parse_move(board, "e2e4").uci() == "e2e4"
    assert parse_move(board, "e5") is None  # невозможный ход


def test_parse_castling():
    board = chess.Board("r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1")
    assert parse_move(board, "O-O").uci() == "e1g1"
    assert parse_move(board, "O-O-O").uci() == "e1c1"


def test_en_passant_and_promotion():
    board = chess.Board("8/8/8/3pP3/8/8/8/k1K5 w - d6 0 1")
    assert parse_move(board, "exd6").uci() == "e5d6"
    board = chess.Board("8/P7/8/8/8/8/8/k1K5 w - - 0 1")
    assert parse_move(board, "a8q").uci() == "a7a8q"


def test_checkmate_detection():
    game = ChessGame()
    game.board = chess.Board("rnb1kbnr/pppp1ppp/8/4p3/6Pq/5P2/PPPPP2P/RNBQKBNR w KQkq - 1 3")
    assert game.is_over
    assert game.result == GameResult.CHECKMATE
    assert game.winner_color == chess.BLACK


def test_bot_all_difficulties_legal():
    for diff in Difficulty:
        board = chess.Board()
        move = bot_move(board, diff)
        assert move in board.legal_moves


def test_medium_bot_returns_legal_move():
    board = chess.Board()
    move = bot_move(board, Difficulty.MEDIUM)
    assert move in board.legal_moves


def test_hint_is_legal():
    board = chess.Board()
    assert parse_move(board, hint(board)) is not None


def test_takeback():
    game = ChessGame()
    game.push(parse_move(game.board, "e4"))
    game.push(bot_move(game.board, Difficulty.EASY))
    assert game.takeback()
    assert len(game.board.move_stack) == 0
    assert not game.takeback()


def test_api_move():
    from fastapi.testclient import TestClient
    from server import app

    client = TestClient(app)
    home = client.get("/")
    assert home.status_code == 200
    assert "Шахматы против бота" in home.text

    r = client.post("/api/move", json={"fen": chess.STARTING_FEN, "difficulty": 2})
    assert r.status_code == 200
    body = r.json()
    assert chess.Move.from_uci(body["move"]) in chess.Board().legal_moves
    assert body["san"]

    r = client.post("/api/move", json={"fen": "not-a-fen", "difficulty": 2})
    assert r.status_code == 400

    # законченная партия — ходить нельзя
    mate_fen = "rnb1kbnr/pppp1ppp/8/4p3/6Pq/5P2/PPPPP2P/RNBQKBNR w KQkq - 1 3"
    r = client.post("/api/move", json={"fen": mate_fen, "difficulty": 1})
    assert r.status_code == 400


def test_history_san_and_last_move_san():
    game = ChessGame()
    game.push(parse_move(game.board, "e4"))
    game.push(parse_move(game.board, "e5"))
    game.push(parse_move(game.board, "Nf3"))
    assert game.last_move_san() == "Nf3"
    assert game.history_san() == "1. e4 e5 2. Nf3"


def test_api_rejects_invalid_position():
    from fastapi.testclient import TestClient
    from server import app

    client = TestClient(app)
    # FEN syntactically valid, but contains an impossible position (no king).
    response = client.post("/api/move", json={
        "fen": "8/8/8/8/8/8/8/8 w - - 0 1", "difficulty": 1
    })
    assert response.status_code == 400
