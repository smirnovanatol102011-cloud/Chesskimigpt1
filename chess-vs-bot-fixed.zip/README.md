# ♞ Шахматы против бота

Простые шахматы против бота — консольная игра и Telegram Mini App.
Одна и та же игровая логика (Python) работает в обоих интерфейсах.

Все нюансы правил (рокировка, взятие на проходе, превращение, шах/мат/пат,
правило 50 ходов, троекратное повторение) обеспечивает библиотека
[python-chess](https://python-chess.readthedocs.io/).

## Уровни сложности

| Уровень | Алгоритм |
|---|---|
| Лёгкий | случайный ход из разумного подмножества (взятия, шахи) |
| Средний | минимакс глубины 2 (материал + центр) |
| Сложный | минимакс глубины 3 + позиционные таблицы |

## Структура

```
chessbot/            игровая логика и ИИ (общий код)
  engine.py          партия: состояние, цвет, сложность, нотации
  ai.py              бот: 3 уровня сложности, подсказки
console.py           консольный интерфейс
server.py            FastAPI: раздаёт Mini App и считает ходы (/api/move)
web/index.html       Mini App: доска, ходы мышью, настройки
bots/telegram_bot.py бот aiogram: кнопка открытия Mini App
tests/test_core.py   тесты
```

## Консольная игра

```bash
python -m pip install -r requirements.txt
python console.py
```

Ходы вводятся в шахматной нотации (`e4`, `Nf3`, `O-O`, `exd5`) или
координатами (`e2e4`). Превращение пешки: `e7e8q`.
Команды: `hint` (подсказка), `takeback` (отмена хода), `new`, `quit`.

## Telegram Mini App

### 1. Создайте бота

1. Напишите [@BotFather](https://t.me/BotFather), команда `/newbot` → получите токен.
2. Команда `/newapp` у BotFather: выберите бота, задайте название и
   **URL Mini App** — публичный https-адрес вашего деплоя (шаг 3).

### 2. Локальный запуск сервера (разработка)

```bash
python -m pip install -r requirements.txt
uvicorn server:app --reload --port 8000
```
Откройте http://localhost:8000 — доска доступна и в браузере.

### 3. Деплой сервера (нужен публичный HTTPS)

Подойдёт любой хостинг с HTTPS, например **Render** (бесплатно):

1. Залейте этот репозиторий на GitHub.
2. На Render: *New → Web Service* → ваш репозиторий.
   - Build: `pip install -r requirements.txt`
   - Start: `uvicorn server:app --host 0.0.0.0 --port $PORT`

### 4. Запуск Telegram-бота

```bash
cp .env.example .env   # вставьте BOT_TOKEN и публичный HTTPS WEBAPP_URL
python bots/telegram_bot.py
```

Команда `/start` → кнопка «Играть в шахматы» открывает Mini App.

## Важно перед запуском

- Для Mini App сервер должен быть доступен по публичному HTTPS-адресу.
- В `.env` для Telegram-бота обязательны `BOT_TOKEN` и `WEBAPP_URL`; URL должен начинаться с `https://`.
- Для локальной проверки в браузере запустите сервер и откройте `http://localhost:8000`. Telegram Mini App локальный HTTP-адрес не примет.

## Тесты

```bash
python -m pytest tests/
```

## Лицензия

MIT
