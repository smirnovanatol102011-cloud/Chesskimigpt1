# -*- coding: utf-8 -*-
"""
Сервер Mini App: раздаёт статику (web/) и считает ходы бота.

Запуск локально:  uvicorn server:app --host 0.0.0.0 --port 8000
Деплой: любой хост с HTTPS (Telegram требует https для Mini App) —
        например, Railway, Render, VPS + nginx.
"""

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from pathlib import Path
from pydantic import BaseModel, Field

import chess

from chessbot.ai import bot_move
from chessbot.engine import Difficulty

BASE_DIR = Path(__file__).resolve().parent
WEB_DIR = BASE_DIR / "web"

app = FastAPI(title="Chess vs Bot — Mini App backend")


class MoveRequest(BaseModel):
    fen: str
    difficulty: int = Field(default=2, ge=1, le=3)


class MoveResponse(BaseModel):
    move: str          # UCI, например "e2e4" или "e7e8q"
    san: str           # человекочитаемая нотация, например "Nf3"


@app.post("/api/move", response_model=MoveResponse)
def api_move(req: MoveRequest):
    """Получить ход бота для позиции FEN."""
    try:
        board = chess.Board(req.fen)
    except (ValueError, TypeError):
        raise HTTPException(status_code=400, detail="Некорректный FEN")
    if not board.is_valid():
        raise HTTPException(status_code=400, detail="Некорректная позиция")
    if board.is_game_over(claim_draw=True):
        raise HTTPException(status_code=400, detail="Игра уже окончена")

    move = bot_move(board, Difficulty(req.difficulty))
    return MoveResponse(move=move.uci(), san=board.san(move))


@app.get("/", include_in_schema=False)
def index():
    return FileResponse(WEB_DIR / "index.html")
