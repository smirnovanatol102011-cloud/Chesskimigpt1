# -*- coding: utf-8 -*-
"""
Искусственный интеллект бота: три уровня сложности.

- лёгкий:  случайный ход из разумного подмножества (взятия, шахи);
- средний: минимакс глубины 2 с альфа-бета отсечением (материал + центр);
- тяжёлый: минимакс глубины 3 + классические позиционные таблицы.
"""

import math
import random

import chess

from .engine import Difficulty

PIECE_VALUES = {
    chess.PAWN: 100,
    chess.KNIGHT: 320,
    chess.BISHOP: 330,
    chess.ROOK: 500,
    chess.QUEEN: 900,
    chess.KING: 0,
}

CENTER_SQUARES = {chess.D4, chess.E4, chess.D5, chess.E5}


def _mirror(table):
    return tuple(reversed(table))


# Позиционные таблицы (a8..h1, с точки зрения белых) — классика (Simplified Evaluation Function)
PAWN_TABLE = (
      0,  0,  0,  0,  0,  0,  0,  0,
      5, 10, 10,-20,-20, 10, 10,  5,
      5, -5,-10,  0,  0,-10, -5,  5,
      0,  0,  0, 20, 20,  0,  0,  0,
      5,  5, 10, 25, 25, 10,  5,  5,
     10, 10, 20, 30, 30, 20, 10, 10,
     50, 50, 50, 50, 50, 50, 50, 50,
      0,  0,  0,  0,  0,  0,  0,  0)

KNIGHT_TABLE = (
    -50,-40,-30,-30,-30,-30,-40,-50,
    -40,-20,  0,  5,  5,  0,-20,-40,
    -30,  5, 10, 15, 15, 10,  5,-30,
    -30,  0, 15, 20, 20, 15,  0,-30,
    -30,  5, 15, 20, 20, 15,  5,-30,
    -30,  0, 10, 15, 15, 10,  0,-30,
    -40,-20,  0,  0,  0,  0,-20,-40,
    -50,-40,-30,-30,-30,-30,-40,-50)

BISHOP_TABLE = (
    -20,-10,-10,-10,-10,-10,-10,-20,
    -10,  5,  0,  0,  0,  0,  5,-10,
    -10, 10, 10, 10, 10, 10, 10,-10,
    -10,  0, 10, 10, 10, 10,  0,-10,
    -10,  5,  5, 10, 10,  5,  5,-10,
    -10,  0,  5, 10, 10,  5,  0,-10,
    -10,  0,  0,  0,  0,  0,  0,-10,
    -20,-10,-10,-10,-10,-10,-10,-20)

ROOK_TABLE = (
      0,  0,  0,  5,  5,  0,  0,  0,
     -5,  0,  0,  0,  0,  0,  0, -5,
     -5,  0,  0,  0,  0,  0,  0, -5,
     -5,  0,  0,  0,  0,  0,  0, -5,
     -5,  0,  0,  0,  0,  0,  0, -5,
     -5,  0,  0,  0,  0,  0,  0, -5,
      5, 10, 10, 10, 10, 10, 10,  5,
      0,  0,  0,  0,  0,  0,  0,  0)

QUEEN_TABLE = (
    -20,-10,-10, -5, -5,-10,-10,-20,
    -10,  0,  5,  0,  0,  0,  0,-10,
    -10,  5,  5,  5,  5,  5,  0,-10,
      0,  0,  5,  5,  5,  5,  0, -5,
     -5,  0,  5,  5,  5,  5,  0, -5,
    -10,  0,  5,  5,  5,  5,  0,-10,
    -10,  0,  0,  0,  0,  0,  0,-10,
    -20,-10,-10, -5, -5,-10,-10,-20)

KING_TABLE = (
     20, 30, 10,  0,  0, 10, 30, 20,
     20, 20,  0,  0,  0,  0, 20, 20,
    -10,-20,-20,-20,-20,-20,-20,-10,
    -20,-30,-30,-40,-40,-30,-30,-20,
    -30,-40,-40,-50,-50,-40,-40,-30,
    -30,-40,-40,-50,-50,-40,-40,-30,
    -30,-40,-40,-50,-50,-40,-40,-30,
    -30,-40,-40,-50,-50,-40,-40,-30)

POSITION_TABLES = {
    chess.PAWN: (PAWN_TABLE, _mirror(PAWN_TABLE)),
    chess.KNIGHT: (KNIGHT_TABLE, _mirror(KNIGHT_TABLE)),
    chess.BISHOP: (BISHOP_TABLE, _mirror(BISHOP_TABLE)),
    chess.ROOK: (ROOK_TABLE, _mirror(ROOK_TABLE)),
    chess.QUEEN: (QUEEN_TABLE, _mirror(QUEEN_TABLE)),
    chess.KING: (KING_TABLE, _mirror(KING_TABLE)),
}


def evaluate(board: chess.Board, positional: bool = False) -> float:
    """Оценка позиции в сотых пешки, с точки зрения белых."""
    if board.is_checkmate():
        return -math.inf if board.turn == chess.WHITE else math.inf
    if board.is_stalemate() or board.is_insufficient_material() \
            or board.is_fifty_moves() or board.can_claim_threefold_repetition():
        return 0

    score = 0
    for square, piece in board.piece_map().items():
        value = PIECE_VALUES[piece.piece_type]
        if positional:
            value += POSITION_TABLES[piece.piece_type][piece.color][square]
        elif square in CENTER_SQUARES and piece.piece_type in (chess.PAWN, chess.KNIGHT, chess.BISHOP):
            value += 10
        score += value if piece.color == chess.WHITE else -value
    return score


def _ordered_moves(board: chess.Board):
    """Взятия и шахи первыми — альфа-бета отсекает заметно быстрее."""
    moves = list(board.legal_moves)
    moves.sort(key=lambda m: board.is_capture(m) or board.gives_check(m), reverse=True)
    return moves


def _minimax(board: chess.Board, depth: int, alpha: float, beta: float,
             positional: bool = False) -> float:
    if depth == 0 or board.is_game_over():
        return evaluate(board, positional)

    if board.turn == chess.WHITE:  # максимизируем
        best = -math.inf
        for move in _ordered_moves(board):
            board.push(move)
            best = max(best, _minimax(board, depth - 1, alpha, beta, positional))
            board.pop()
            alpha = max(alpha, best)
            if beta <= alpha:
                break
        return best

    best = math.inf  # минимизируем
    for move in _ordered_moves(board):
        board.push(move)
        best = min(best, _minimax(board, depth - 1, alpha, beta, positional))
        board.pop()
        beta = min(beta, best)
        if beta <= alpha:
            break
    return best


def _best_move(board: chess.Board, depth: int, positional: bool = False) -> chess.Move:
    best_score = -math.inf if board.turn == chess.WHITE else math.inf
    candidates = []

    for move in _ordered_moves(board):
        board.push(move)
        score = _minimax(board, depth - 1, -math.inf, math.inf, positional)
        board.pop()

        if board.turn == chess.WHITE:
            better = score > best_score
        else:
            better = score < best_score

        if better:
            best_score = score
            candidates = [move]
        elif score == best_score:
            candidates.append(move)

    # Среди равных по оценке — случайный, чтобы партии не повторялись
    return random.choice(candidates)


def _easy_move(board: chess.Board) -> chess.Move:
    """Лёгкий бот: охотится за фигурами и шахами, но в целом ходит случайно."""
    moves = list(board.legal_moves)
    captures = [m for m in moves if board.is_capture(m)]
    checks = [m for m in moves if board.gives_check(m)]
    if captures and random.random() < 0.7:
        return random.choice(captures)
    if checks and random.random() < 0.5:
        return random.choice(checks)
    return random.choice(moves)


def bot_move(board: chess.Board, difficulty: Difficulty) -> chess.Move:
    """Ход бота для текущей позиции."""
    difficulty = Difficulty(difficulty)
    if difficulty == Difficulty.EASY:
        return _easy_move(board)
    if difficulty == Difficulty.MEDIUM:
        return _best_move(board, depth=2, positional=False)
    return _best_move(board, depth=3, positional=True)


def hint(board: chess.Board) -> str:
    """Рекомендуемый ход (как играл бы «средний» бот) в нотации SAN."""
    return board.san(_best_move(board, depth=2, positional=False))
