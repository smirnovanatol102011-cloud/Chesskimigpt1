# -*- coding: utf-8 -*-
"""
Игровой движок: состояние партии и правила.

Все нюансы правил (рокировка, взятие на проходе, превращение, шах/мат/пат,
правило 50 ходов, троекратное повторение) обеспечивает библиотека python-chess.
"""

import enum
from typing import Optional

import chess


class Difficulty(enum.IntEnum):
    """Уровни сложности бота."""
    EASY = 1     # случайный ход из разумного подмножества
    MEDIUM = 2   # минимакс глубины 2 (материал + центр)
    HARD = 3     # минимакс глубины 3 (материал + позиционные таблицы)


class GameResult(enum.Enum):
    ONGOING = "ongoing"
    CHECKMATE = "checkmate"
    STALEMATE = "stalemate"
    DRAW = "draw"


class ChessGame:
    """Одна партия человек против бота."""

    def __init__(self, human_color: int = chess.WHITE,
                 difficulty: Difficulty = Difficulty.MEDIUM):
        self.board = chess.Board()
        self.human_color = human_color
        self.difficulty = difficulty

    @property
    def is_human_turn(self) -> bool:
        return self.board.turn == self.human_color

    @property
    def is_over(self) -> bool:
        return self.board.is_game_over()

    @property
    def result(self) -> GameResult:
        b = self.board
        if b.is_checkmate():
            return GameResult.CHECKMATE
        if b.is_stalemate():
            return GameResult.STALEMATE
        if b.is_insufficient_material() or b.is_fifty_moves() \
                or b.can_claim_threefold_repetition():
            return GameResult.DRAW
        return GameResult.ONGOING

    @property
    def winner_color(self) -> Optional[int]:
        """Цвет победителя, если мат."""
        if self.board.is_checkmate():
            return chess.BLACK if self.board.turn == chess.WHITE else chess.WHITE
        return None

    def parse_human_move(self, text: str) -> Optional[chess.Move]:
        """Разобрать ввод человека: SAN (e4, Nf3, O-O) или UCI (e2e4)."""
        return parse_move(self.board, text)

    def push(self, move: chess.Move) -> None:
        self.board.push(move)

    def takeback(self) -> bool:
        """Отменить ход человека и ответ бота. False, если отменять нечего."""
        if len(self.board.move_stack) < 2:
            return False
        self.board.pop()
        self.board.pop()
        return True

    def last_move_san(self) -> str:
        """SAN последнего хода (для протокола партии)."""
        if not self.board.move_stack:
            return ""
        replay = self.board.copy()
        move = replay.pop()
        return replay.san(move)

    def history_san(self) -> str:
        """Партия в стандартной нотации, например: 1. e4 e5 2. Nf3 Nc6."""
        # Восстанавливаем нотацию последовательно от начальной позиции.
        replay = chess.Board()
        parts = []
        for i, move in enumerate(self.board.move_stack):
            san = replay.san(move)
            if i % 2 == 0:
                parts.append(f"{i // 2 + 1}. {san}")
            else:
                parts[-1] += f" {san}"
            replay.push(move)
        return " ".join(parts)

    def render(self) -> str:
        """Доска для вывода в текстовом интерфейсе."""
        return render_board(self.board)


def parse_move(board: chess.Board, text: str) -> Optional[chess.Move]:
    """Разобрать строку в легальный ход; None, если невозможно."""
    text = text.strip()
    try:
        move = board.parse_san(text)
    except ValueError:
        try:
            move = chess.Move.from_uci(text)
        except ValueError:
            return None
    return move if move in board.legal_moves else None


def render_board(board: chess.Board) -> str:
    """ASCII-доска с указанием стороны и номера хода."""
    turn = "Белые" if board.turn == chess.WHITE else "Чёрные"
    return f"{board}\n\nХод: {turn} | Ход № {board.fullmove_number}"
